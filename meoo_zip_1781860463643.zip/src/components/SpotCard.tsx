import { RefreshCw, ThumbsDown, CheckCircle2 } from "lucide-react";
import type { Spot } from "@/lib/spots";

interface SpotCardProps {
  spot: Spot;
  distance?: number;
  onRetry: () => void;
  onExclude: (name: string, reason: "not_interested" | "visited") => void;
}

export function SpotCard({ spot, distance, onRetry, onExclude }: SpotCardProps) {
  return (
    <div className="border-t pt-4 mt-4">
      {/* 景点图片 */}
      <div className="w-full h-56 bg-secondary mb-4 overflow-hidden">
        {spot.imgUrl ? (
          <img
            src={spot.imgUrl}
            alt={spot.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground text-sm">
            暂无图片
          </div>
        )}
      </div>

      {/* 内容区 */}
      <div className="space-y-3">
        <div className="flex items-baseline justify-between">
          <h2 className="text-lg font-semibold">{spot.name}</h2>
          {distance !== undefined && (
            <span className="text-xs text-muted-foreground">
              {distance.toFixed(1)}km
            </span>
          )}
        </div>

        <p className="text-sm text-muted-foreground leading-relaxed">
          {spot.desc}
        </p>

        {/* 标签 */}
        <div className="flex gap-2 flex-wrap">
          {spot.tags.map((tag) => (
            <span key={tag} className="text-xs text-muted-foreground">
              #{tag}
            </span>
          ))}
        </div>

        {/* 操作按钮组 */}
        <div className="flex gap-2 mt-4">
          <button
            onClick={() => onExclude(spot.name, "not_interested")}
            className="flex-1 border rounded-md py-2 text-xs font-medium flex items-center justify-center gap-1.5 hover:bg-secondary transition-colors text-muted-foreground"
          >
            <ThumbsDown className="w-3.5 h-3.5" />
            不感兴趣
          </button>
          <button
            onClick={() => onExclude(spot.name, "visited")}
            className="flex-1 border rounded-md py-2 text-xs font-medium flex items-center justify-center gap-1.5 hover:bg-secondary transition-colors text-muted-foreground"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            已去过
          </button>
          <button
            onClick={onRetry}
            className="flex-1 bg-primary text-primary-foreground rounded-md py-2 text-xs font-medium flex items-center justify-center gap-1.5 hover:bg-primary/90 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            换一个
          </button>
        </div>
      </div>
    </div>
  );
}
