/**
 * 高德地图API服务模块
 * 
 * 使用前请设置环境变量：VITE_AMAP_KEY=你的高德Web服务Key
 * 或在下方 AMAP_KEY 处直接填入Key（仅开发调试用）
 */

// ⚠️ 在此处填入你的高德Web服务Key，或通过环境变量 VITE_AMAP_KEY 注入
const AMAP_KEY = import.meta.env.VITE_AMAP_KEY || "";

/**
 * 逆地理编码：经纬度 → 省/市/区
 */
export async function reverseGeocode(lat: number, lng: number): Promise<{
  province: string;
  city: string;
  district: string;
} | null> {
  if (!AMAP_KEY) {
    console.warn("[高德] 未配置 VITE_AMAP_KEY，跳过逆地理编码");
    return null;
  }

  try {
    const resp = await fetch(
      `https://restapi.amap.com/v3/geocode/regeo?key=${AMAP_KEY}&location=${lng},${lat}&extensions=base`
    );
    const data = await resp.json();

    if (data.status === "1" && data.regeocode) {
      const addr = data.regeocode.addressComponent;
      return {
        province: addr.province || "",
        city: Array.isArray(addr.city) ? "" : addr.city || "",
        district: addr.district || "",
      };
    }
    return null;
  } catch (err) {
    console.error("[高德] 逆地理编码失败:", err);
    return null;
  }
}

export interface AmapPoi {
  name: string;
  lat: number;
  lng: number;
  district: string;
  city: string;
  province: string;
  tags: string[];
  imgUrl?: string;
  desc: string;
}

/**
 * POI搜索：根据关键词和范围获取景点数据
 * @param keyword 搜索关键词，如"景点"
 * @param options 筛选选项
 */
export async function searchPoi(
  keyword: string,
  options: {
    location?: { lat: number; lng: number };
    radius?: number;       // 单位：米
    city?: string;         // 城市名称或adcode
    page?: number;
    pageSize?: number;
  } = {}
): Promise<AmapPoi[]> {
  if (!AMAP_KEY) {
    console.warn("[高德] 未配置 VITE_AMAP_KEY，POI搜索返回空");
    return [];
  }

  const params = new URLSearchParams({
    key: AMAP_KEY,
    keywords: keyword,
    types: "110000|110100|110200", // 风景名胜大类
    offset: String(options.pageSize || 25),
    page: String(options.page || 1),
    extensions: "all",
    output: "json",
  });

  if (options.location) {
    params.set("location", `${options.location.lng},${options.location.lat}`);
  }
  if (options.radius) {
    params.set("radius", String(options.radius));
  }
  if (options.city) {
    params.set("city", options.city);
  }

  try {
    const resp = await fetch(`https://restapi.amap.com/v3/place/text?${params.toString()}`);
    const data = await resp.json();

    if (data.status === "1" && data.pois) {
      return data.pois.map((poi: Record<string, unknown>) => {
        const [lng, lat] = (poi.location as string).split(",").map(Number);
        const photos = poi.photos as Array<{ url: string }> | undefined;
        return {
          name: poi.name as string,
          lat,
          lng,
          district: (poi.adname as string) || "",
          city: (poi.cityname as string) || "",
          province: (poi.pname as string) || "",
          tags: ((poi.type as string) || "").split(";").filter(Boolean).slice(0, 3),
          imgUrl: photos?.[0]?.url || undefined,
          desc: (poi.biz_ext as Record<string, string>)?.rating
            ? `评分 ${(poi.biz_ext as Record<string, string>).rating} · ${poi.address || ""}`
            : (poi.address as string) || "",
        };
      });
    }
    return [];
  } catch (err) {
    console.error("[高德] POI搜索失败:", err);
    return [];
  }
}

/**
 * 检查Key是否已配置
 */
export function isAmapConfigured(): boolean {
  return !!AMAP_KEY;
}
