/**
 * 景点数据Mock和工具函数
 */

export interface Spot {
  name: string;
  lat: number;
  lng: number;
  district: string;
  city: string;
  province: string;
  tags: string[];
  imgUrl?: string;
  desc: string;
}

/**
 * Mock景点数据 - 覆盖全国各省市
 */
export const MOCK_SPOTS: Spot[] = [
  // 浙江省
  { name: "灵隐寺", lat: 30.242, lng: 120.135, district: "西湖区", city: "杭州市", province: "浙江省", tags: ["人文", "祈福"], imgUrl: "https://picsum.photos/seed/lingyin/800/400", desc: "千年古刹，禅意深远，飞来峰石刻艺术精湛。" },
  { name: "西湖", lat: 30.25, lng: 120.15, district: "西湖区", city: "杭州市", province: "浙江省", tags: ["自然", "湖景"], imgUrl: "https://picsum.photos/seed/westlake/800/400", desc: "人间天堂，淡妆浓抹总相宜。" },
  { name: "千岛湖", lat: 29.59, lng: 119.02, district: "淳安县", city: "杭州市", province: "浙江省", tags: ["湖泊", "度假"], imgUrl: "https://picsum.photos/seed/qiandao/800/400", desc: "天下第一秀水，岛屿星罗棋布。" },
  { name: "乌镇", lat: 30.75, lng: 120.48, district: "桐乡市", city: "嘉兴市", province: "浙江省", tags: ["古镇", "水乡"], imgUrl: "https://picsum.photos/seed/wuzhen/800/400", desc: "江南水乡典范，小桥流水人家。" },
  { name: "普陀山", lat: 29.98, lng: 122.39, district: "普陀区", city: "舟山市", province: "浙江省", tags: ["佛教", "海岛"], imgUrl: "https://picsum.photos/seed/putuo/800/400", desc: "海天佛国，观音道场。" },
  { name: "雁荡山", lat: 28.37, lng: 121.11, district: "乐清市", city: "温州市", province: "浙江省", tags: ["山水", "地质"], imgUrl: "https://picsum.photos/seed/yandang/800/400", desc: "东南第一山，奇峰怪石林立。" },
  // 北京市
  { name: "故宫", lat: 39.92, lng: 116.4, district: "东城区", city: "北京市", province: "北京市", tags: ["历史", "皇家"], imgUrl: "https://picsum.photos/seed/gugong/800/400", desc: "明清两代皇宫，世界文化遗产。" },
  { name: "长城", lat: 40.43, lng: 116.57, district: "延庆区", city: "北京市", province: "北京市", tags: ["历史", "徒步"], imgUrl: "https://picsum.photos/seed/greatwall/800/400", desc: "不到长城非好汉，中华民族的象征。" },
  { name: "颐和园", lat: 39.99, lng: 116.27, district: "海淀区", city: "北京市", province: "北京市", tags: ["园林", "皇家"], imgUrl: "https://picsum.photos/seed/yiheyuan/800/400", desc: "皇家园林博物馆，昆明湖万寿山。" },
  { name: "天坛", lat: 39.88, lng: 116.41, district: "东城区", city: "北京市", province: "北京市", tags: ["历史", "祭祀"], imgUrl: "https://picsum.photos/seed/tiantan/800/400", desc: "明清皇帝祭天之所，建筑精妙绝伦。" },
  // 上海市
  { name: "外滩", lat: 31.24, lng: 121.49, district: "黄浦区", city: "上海市", province: "上海市", tags: ["夜景", "建筑"], imgUrl: "https://picsum.photos/seed/waitan/800/400", desc: "万国建筑博览群，上海城市名片。" },
  { name: "东方明珠", lat: 31.24, lng: 121.5, district: "浦东新区", city: "上海市", province: "上海市", tags: ["地标", "观景"], imgUrl: "https://picsum.photos/seed/dongfang/800/400", desc: "上海城市象征，俯瞰浦江两岸。" },
  { name: "豫园", lat: 31.23, lng: 121.49, district: "黄浦区", city: "上海市", province: "上海市", tags: ["园林", "古典"], imgUrl: "https://picsum.photos/seed/yuyuan/800/400", desc: "明代古典园林，城隍庙旁古韵悠长。" },
  // 江苏省
  { name: "拙政园", lat: 31.32, lng: 120.63, district: "姑苏区", city: "苏州市", province: "江苏省", tags: ["园林", "世界遗产"], imgUrl: "https://picsum.photos/seed/zhuozheng/800/400", desc: "中国四大名园之一，江南园林代表。" },
  { name: "中山陵", lat: 32.06, lng: 118.85, district: "玄武区", city: "南京市", province: "江苏省", tags: ["历史", "纪念"], imgUrl: "https://picsum.photos/seed/zhongshan/800/400", desc: "孙中山先生陵寝，庄严肃穆。" },
  { name: "鼋头渚", lat: 31.52, lng: 120.22, district: "滨湖区", city: "无锡市", province: "江苏省", tags: ["湖景", "樱花"], imgUrl: "https://picsum.photos/seed/yuantouzhu/800/400", desc: "太湖绝佳处，春日樱花如云。" },
  // 安徽省
  { name: "黄山", lat: 30.13, lng: 118.17, district: "黄山区", city: "黄山市", province: "安徽省", tags: ["山水", "云海"], imgUrl: "https://picsum.photos/seed/huangshan/800/400", desc: "五岳归来不看山，黄山归来不看岳。" },
  { name: "宏村", lat: 29.9, lng: 117.98, district: "黟县", city: "黄山市", province: "安徽省", tags: ["古村落", "徽派"], imgUrl: "https://picsum.photos/seed/hongcun/800/400", desc: "画里乡村，徽派建筑博物馆。" },
  // 湖南省
  { name: "张家界", lat: 29.12, lng: 110.48, district: "永定区", city: "张家界市", province: "湖南省", tags: ["奇峰", "自然"], imgUrl: "https://picsum.photos/seed/zhangjiajie/800/400", desc: "阿凡达取景地，奇峰三千秀水八百。" },
  { name: "凤凰古城", lat: 27.95, lng: 109.6, district: "凤凰县", city: "湘西州", province: "湖南省", tags: ["古城", "民族"], imgUrl: "https://picsum.photos/seed/fenghuang/800/400", desc: "沈从文笔下的边城，沱江畔的吊脚楼。" },
  { name: "岳麓山", lat: 28.18, lng: 112.94, district: "岳麓区", city: "长沙市", province: "湖南省", tags: ["名山", "书院"], imgUrl: "https://picsum.photos/seed/yuelu/800/400", desc: "千年学府岳麓书院，爱晚亭红叶。" },
  // 四川省
  { name: "九寨沟", lat: 33.2, lng: 103.92, district: "九寨沟县", city: "阿坝州", province: "四川省", tags: ["湖泊", "彩林"], imgUrl: "https://picsum.photos/seed/jiuzhai/800/400", desc: "童话世界，五彩斑斓的人间仙境。" },
  { name: "峨眉山", lat: 29.6, lng: 103.48, district: "峨眉山市", city: "乐山市", province: "四川省", tags: ["佛教", "云海"], imgUrl: "https://picsum.photos/seed/emei/800/400", desc: "普贤菩萨道场，金顶日出壮观。" },
  { name: "都江堰", lat: 31.0, lng: 103.62, district: "都江堰市", city: "成都市", province: "四川省", tags: ["水利", "历史"], imgUrl: "https://picsum.photos/seed/dujiangyan/800/400", desc: "两千年前的伟大水利工程。" },
  { name: "稻城亚丁", lat: 28.55, lng: 100.3, district: "稻城县", city: "甘孜州", province: "四川省", tags: ["雪山", "高原"], imgUrl: "https://picsum.photos/seed/daocheng/800/400", desc: "蓝色星球上最后一片净土。" },
  // 云南省
  { name: "丽江古城", lat: 26.87, lng: 100.23, district: "古城区", city: "丽江市", province: "云南省", tags: ["古城", "民族"], imgUrl: "https://picsum.photos/seed/lijiang/800/400", desc: "世界文化遗产，纳西族文化圣地。" },
  { name: "大理古城", lat: 25.69, lng: 100.16, district: "大理市", city: "大理州", province: "云南省", tags: ["古城", "苍山洱海"], imgUrl: "https://picsum.photos/seed/dali/800/400", desc: "风花雪月，苍山洱海间的白族古城。" },
  { name: "石林", lat: 24.82, lng: 103.27, district: "石林县", city: "昆明市", province: "云南省", tags: ["喀斯特", "自然"], imgUrl: "https://picsum.photos/seed/shilin/800/400", desc: "天下第一奇观，喀斯特地貌精华。" },
  { name: "香格里拉", lat: 27.83, lng: 99.71, district: "香格里拉市", city: "迪庆州", province: "云南省", tags: ["高原", "藏族"], imgUrl: "https://picsum.photos/seed/xianggelila/800/400", desc: "心中的日月，雪山草甸藏传佛教。" },
  // 福建省
  { name: "鼓浪屿", lat: 24.44, lng: 118.07, district: "思明区", city: "厦门市", province: "福建省", tags: ["海岛", "文艺"], imgUrl: "https://picsum.photos/seed/gulangyu/800/400", desc: "海上花园，钢琴之岛。" },
  { name: "武夷山", lat: 27.75, lng: 118.02, district: "武夷山市", city: "南平市", province: "福建省", tags: ["丹霞", "茶文化"], imgUrl: "https://picsum.photos/seed/wuyi/800/400", desc: "世界双遗产，大红袍故乡。" },
  { name: "土楼", lat: 24.7, lng: 117.0, district: "南靖县", city: "漳州市", province: "福建省", tags: ["民居", "世界遗产"], imgUrl: "https://picsum.photos/seed/tulou/800/400", desc: "客家土楼，东方古城堡。" },
  // 陕西省
  { name: "兵马俑", lat: 34.38, lng: 109.27, district: "临潼区", city: "西安市", province: "陕西省", tags: ["历史", "考古"], imgUrl: "https://picsum.photos/seed/bingmayong/800/400", desc: "世界第八大奇迹，秦朝军事力量见证。" },
  { name: "华山", lat: 34.47, lng: 110.08, district: "华阴市", city: "渭南市", province: "陕西省", tags: ["险峰", "道教"], imgUrl: "https://picsum.photos/seed/huashan/800/400", desc: "奇险天下第一山，自古华山一条路。" },
  { name: "大雁塔", lat: 34.22, lng: 108.96, district: "雁塔区", city: "西安市", province: "陕西省", tags: ["佛教", "唐代"], imgUrl: "https://picsum.photos/seed/dayanta/800/400", desc: "玄奘译经藏经之所，盛唐标志。" },
  // 广东省
  { name: "广州塔", lat: 23.11, lng: 113.32, district: "海珠区", city: "广州市", province: "广东省", tags: ["地标", "夜景"], imgUrl: "https://picsum.photos/seed/guangzhouta/800/400", desc: "小蛮腰，珠江新城地标建筑。" },
  { name: "丹霞山", lat: 25.02, lng: 113.73, district: "仁化县", city: "韶关市", province: "广东省", tags: ["丹霞", "自然"], imgUrl: "https://picsum.photos/seed/danxia/800/400", desc: "丹霞地貌命名地，赤壁丹崖。" },
  { name: "开平碉楼", lat: 22.38, lng: 112.67, district: "开平市", city: "江门市", province: "广东省", tags: ["侨乡", "建筑"], imgUrl: "https://picsum.photos/seed/kaiping/800/400", desc: "中西合璧的华侨建筑群。" },
  // 海南省
  { name: "三亚湾", lat: 18.25, lng: 109.51, district: "天涯区", city: "三亚市", province: "海南省", tags: ["海滩", "度假"], imgUrl: "https://picsum.photos/seed/sanya/800/400", desc: "热带海滨，阳光沙滩椰林。" },
  { name: "蜈支洲岛", lat: 18.31, lng: 109.76, district: "海棠区", city: "三亚市", province: "海南省", tags: ["海岛", "潜水"], imgUrl: "https://picsum.photos/seed/wuzhizhou/800/400", desc: "中国的马尔代夫，碧海蓝天。" },
  // 甘肃省
  { name: "敦煌莫高窟", lat: 40.04, lng: 94.8, district: "敦煌市", city: "酒泉市", province: "甘肃省", tags: ["艺术", "佛教"], imgUrl: "https://picsum.photos/seed/mogaoku/800/400", desc: "东方艺术明珠，千年佛教壁画宝库。" },
  { name: "鸣沙山月牙泉", lat: 40.08, lng: 94.67, district: "敦煌市", city: "酒泉市", province: "甘肃省", tags: ["沙漠", "奇观"], imgUrl: "https://picsum.photos/seed/mingsha/800/400", desc: "沙泉共处，大漠中的奇迹。" },
  // 西藏自治区
  { name: "布达拉宫", lat: 29.65, lng: 91.12, district: "城关区", city: "拉萨市", province: "西藏自治区", tags: ["宗教", "宫殿"], imgUrl: "https://picsum.photos/seed/budalagong/800/400", desc: "雪域高原的圣殿，藏传佛教圣地。" },
  { name: "纳木错", lat: 30.7, lng: 90.5, district: "当雄县", city: "拉萨市", province: "西藏自治区", tags: ["圣湖", "高原"], imgUrl: "https://picsum.photos/seed/namucuo/800/400", desc: "天湖，世界海拔最高的大型湖泊。" },
  // 新疆维吾尔自治区
  { name: "喀纳斯", lat: 48.71, lng: 87.02, district: "布尔津县", city: "阿勒泰地区", province: "新疆维吾尔自治区", tags: ["湖泊", "秋色"], imgUrl: "https://picsum.photos/seed/kanas/800/400", desc: "人间净土，神秘的变色湖。" },
  { name: "天山天池", lat: 43.88, lng: 88.12, district: "阜康市", city: "昌吉州", province: "新疆维吾尔自治区", tags: ["高山湖", "雪山"], imgUrl: "https://picsum.photos/seed/tianshan/800/400", desc: "瑶池仙境，雪峰环抱的高山湖泊。" },
  // 广西壮族自治区
  { name: "桂林山水", lat: 25.27, lng: 110.29, district: "秀峰区", city: "桂林市", province: "广西壮族自治区", tags: ["山水", "漓江"], imgUrl: "https://picsum.photos/seed/guilin/800/400", desc: "桂林山水甲天下，漓江风光如画。" },
  { name: "阳朔西街", lat: 24.77, lng: 110.49, district: "阳朔县", city: "桂林市", province: "广西壮族自治区", tags: ["古镇", "休闲"], imgUrl: "https://picsum.photos/seed/yangshuo/800/400", desc: "洋人街，遇龙河畔的悠闲时光。" },
  // 山东省
  { name: "泰山", lat: 36.25, lng: 117.1, district: "泰山区", city: "泰安市", province: "山东省", tags: ["五岳", "日出"], imgUrl: "https://picsum.photos/seed/taishan/800/400", desc: "五岳之首，登泰山而小天下。" },
  { name: "崂山", lat: 36.1, lng: 120.6, district: "崂山区", city: "青岛市", province: "山东省", tags: ["道教", "海景"], imgUrl: "https://picsum.photos/seed/laoshan/800/400", desc: "海上名山第一，道教圣地。" },
  // 河南省
  { name: "少林寺", lat: 34.51, lng: 112.95, district: "登封市", city: "郑州市", province: "河南省", tags: ["武术", "佛教"], imgUrl: "https://picsum.photos/seed/shaolin/800/400", desc: "天下武功出少林，禅宗祖庭。" },
  { name: "龙门石窟", lat: 34.57, lng: 112.47, district: "洛龙区", city: "洛阳市", province: "河南省", tags: ["石刻", "世界遗产"], imgUrl: "https://picsum.photos/seed/longmen/800/400", desc: "中国石刻艺术巅峰之作。" },
  // 江西省
  { name: "庐山", lat: 29.59, lng: 115.97, district: "庐山市", city: "九江市", province: "江西省", tags: ["避暑", "瀑布"], imgUrl: "https://picsum.photos/seed/lushan/800/400", desc: "不识庐山真面目，只缘身在此山中。" },
  { name: "婺源", lat: 29.25, lng: 117.86, district: "婺源县", city: "上饶市", province: "江西省", tags: ["油菜花", "古村落"], imgUrl: "https://picsum.photos/seed/wuyuan/800/400", desc: "中国最美乡村，春日油菜花海。" },
  // 贵州省
  { name: "黄果树瀑布", lat: 25.99, lng: 105.67, district: "镇宁县", city: "安顺市", province: "贵州省", tags: ["瀑布", "自然"], imgUrl: "https://picsum.photos/seed/huangguoshu/800/400", desc: "亚洲最大瀑布，气势磅礴。" },
  { name: "西江千户苗寨", lat: 26.5, lng: 108.17, district: "雷山县", city: "黔东南州", province: "贵州省", tags: ["苗族", "夜景"], imgUrl: "https://picsum.photos/seed/xijiang/800/400", desc: "世界最大苗寨，万家灯火如星河。" },
];

/**
 * Haversine公式计算球面距离(单位:公里)
 */
export function haversineDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * 根据筛选条件过滤景点
 */
export function filterSpots(
  spots: Spot[],
  userLocation: { lat: number; lng: number } | null,
  userRegion: { district: string; city: string; province: string },
  distanceRange: string | null,
  regionRange: string
): Spot[] {
  let filtered = [...spots];

  // 按距离筛选
  if (distanceRange && userLocation) {
    const maxDist = parseInt(distanceRange);
    filtered = filtered.filter((spot) => {
      const dist = haversineDistance(
        userLocation.lat,
        userLocation.lng,
        spot.lat,
        spot.lng
      );
      return dist <= maxDist;
    });
  } else if (regionRange !== "nationwide") {
    // 按行政区域筛选（仅在没有选择距离时生效）
    if (regionRange === "district" && userRegion.district) {
      filtered = filtered.filter((s) => s.district === userRegion.district);
    } else if (regionRange === "city" && userRegion.city) {
      filtered = filtered.filter((s) => s.city === userRegion.city);
    } else if (regionRange === "province" && userRegion.province) {
      filtered = filtered.filter((s) => s.province === userRegion.province);
    }
  }
  // regionRange === "nationwide" 时不做任何过滤，返回全部

  // 无结果时返回全部
  return filtered.length > 0 ? filtered : spots;
}

/**
 * 随机选择一个景点
 */
export function pickRandomSpot(spots: Spot[]): Spot {
  const index = Math.floor(Math.random() * spots.length);
  return spots[index];
}
